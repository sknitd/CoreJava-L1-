/*------------Assignment 15: Packages --------*/

/*-----Objective : To place a class inside a package. Compile the code and save the .class file in a different location using the -d option. See how packages affect the class path.--*/


/*This java file contains a class that depicts the concept of packages----*/


/*Include the package statement because the class should be part of com.enr.MyPackage---*/

package Wipro.TT.ProjectZone;

public class PackageDemo
{
        public static void main(String args[])
        {
                System.out.println("I am part of a package now");
                
        }
}
